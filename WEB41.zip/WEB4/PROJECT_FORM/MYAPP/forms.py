from django import forms
#from .models import Snippet

class ContactForm(forms.Form):
    name = forms .FloatField(label='LET - effective', required=False)
    nametwo = forms.FloatField(label='Cross-section per bit', required=False)
    namethree = forms.FloatField(label='Positive error bars', required=False)
    namefour = forms.FloatField(label='Negative error bar', required=False)
    #---------------------------------------------------------
    #name1 = forms.FloatField(label='LET - effective')
    #name1two = forms.FloatField(label='Cross-section per bit')
    #name1three = forms.FloatField(label='Positive error bars')
    #name1four = forms.FloatField(label='Number of bits1')
    #ame1five = forms.FloatField(label='Number of bits2')

#class SnippetForm(forms.ModelForm):
   # class Meta:
    # model = Snippet
    # fields = ('name', 'nametwo', 'namethree', 'namefour', 'name1', 'name1two', 'name1three', 'name1four', ' name1five')
