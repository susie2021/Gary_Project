#form django import math
def p(x,y,z):
    x=2
    y=3
    z=2+3
    print(2+3)
