from django.shortcuts import render
from django.http import HttpResponse
from .forms import ContactForm


# Create your views here.
def contact(request):
    form = ContactForm(request.POST)
    return render(request, 'form.html', {'form': form, 'OP1': 5.9, 'OP2': 6.5})

# return HttpResponse(request,"<h1>here is the site</h>")
#def snippet_detail(request):
     #if request.method == 'POST':
        #  form = SnippetForm(request.POST)
       #   if form.is_valid():
          #   form.save()






     #form = SnippetForm()
    # return render(request, 'form.html', {'form': form})

